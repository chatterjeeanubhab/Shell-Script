cal
cal -y
cal 10 2020 
cal 2021