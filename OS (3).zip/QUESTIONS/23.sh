f1=$1
echo "NAME ROLL MARKS GRADE" > output.txt

if [ -f $f1 ]
then
   exec < $f1

while read line 
do 

 set -e `echo $line`
 if [ $3 -ge 90 -a $3 -le 100 ]
 then 
    echo "$1   $2   $3   O" >> output.txt
 elif [ $3 -ge 80 -a $3 -lt 89 ]
 then 
    echo "$1   $2   $3   E" >> output.txt
    
  elif [ $3 -ge 70 -a $3 -le 79 ]
 then 
    echo "$1  $2   $3  A" >> output.txt
    
    elif [ $3 -ge 60 -a $3 -le 69 ]
 then 
    echo "$1   $2   $3  B" >> output.txt
    
    elif [ $3 -ge 50 -a $3 -le 59 ]
 then 
    echo "$1   $2   $3  C" >> output.txt
    
   fi   

 done

fi