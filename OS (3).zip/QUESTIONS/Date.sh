#calculate the current time
date +"%T"
#calculate the current date
date +"%d-%m-%y"
#23-Nov 2022 format
date +"%d-%b %Y"
#23/11/22 format
date +"%d/%m/%y"