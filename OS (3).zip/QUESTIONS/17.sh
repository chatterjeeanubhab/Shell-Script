IFS="/"
echo "enter dob::"
read dob
set $dob
d=$1
m=$2
y=$3
dd=`date +%d`
mm=`date +%m`
yy=`date +%Y`

echo "My bday:: $d/$m/$y"
echo "current year $dd/$mm/$yy"

aged=`expr $dd - $d`
agem=`expr $mm - $m`
agey=`expr $yy - $y`


if [ $aged -lt 0 ]
then
 aged=`expr $dd - $d + 31`
else
 aged=`expr $dd - $d` 
fi

if [ $agem -lt 0 ]
then
 agem=`expr $mm - $m + 12`
else
 aged=`expr $mm - $m` 
fi

echo "I am $agey years $agem months $aged days old."

