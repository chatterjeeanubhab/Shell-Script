factorial()
{

n=$1
fact=1
for ((i=1;i<=$n;i++))
do
fact=`expr $fact \* $i`
done
echo $fact

}

#main
echo "Enter terms::"
read terms
echo "Enter value x::"
read x
sum=$x
p=2
for ((i=1; i<= ($terms -1); i++))
do
pow=`echo "$x^$p"|bc`
f=`factorial $p`
s=`echo "scale=3; $pow/$f"|bc`
sum=`echo "scale=3; $sum + $s"|bc`
p=`expr $p + 2`
done

echo "SUM:: $sum"