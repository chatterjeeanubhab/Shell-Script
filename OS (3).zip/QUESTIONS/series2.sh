#1+ (x/2)2 –(x/2)3 + (x/2)4 –(x/2)5+…

echo "Enter terms"
read n
echo "Enter value x::"
read x

val=`echo "scale=2; ($x/2) "|bc`
sum=1
sign=1
for ((i=2;i<=n;i++))
do

sum=`echo "scale=2; $sign * ($sum + ($val ^ $i))"|bc`
sign=`expr $sign * -1`

done

echo "SUM = $sum"