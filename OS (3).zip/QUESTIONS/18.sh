#total characters
wc -m 18.sh
#total words
wc -w 18.sh
#total lines
wc -l
