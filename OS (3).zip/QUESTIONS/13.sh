echo "Enter size of list::"
read n
echo "Enter list elements::"

for ((i=0;i < $n ; i++))
do
read arr[$i]
done

for ((i=0;i<$n;i++))
do
temp=${arr[i]}
count=0
# count the no. of digits in the number
while [ $temp -gt 0 ]
do 
count=`expr $count + 1`
temp=`expr $temp / 10`
done

#power the digits to count

ans=0
temp1=${arr[i]}
while [ $temp1 -gt 0 ]
do
rem=`expr $temp1 % 10`
ans=`echo  $ans + $rem^$count|bc`
temp1=`expr $temp1 / 10`
done

if [ $ans -eq ${arr[i]} ]
  then 
    echo "$ans is armstrong number"
else
    echo "$ans is not an armstrong number"
fi        

done



