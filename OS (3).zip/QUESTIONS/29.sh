a=`ls -l | wc -l`
b=`ls -S | head -n 1` 
echo "no. of files in current directory = `expr $a - 1`"
echo "Name of the largest file = $b"