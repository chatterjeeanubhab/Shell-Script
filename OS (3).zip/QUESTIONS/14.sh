#fibonnaci series 0 1 1 2 3 5 8 .....

echo -n "enter range :: " 
read n
f=0
s=1
echo -n "$f "
echo -n "$s "

for ((i=2;i<n;i++))

do
t=`expr $f + $s`
echo -n "$t "
f=$s
s=$t
done

echo
