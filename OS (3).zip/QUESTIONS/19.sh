echo -n "enter lower range:: "
read a
echo -n "enter upper range:: "
read b

for ((i=a; i<=b; i++))
do
     flag=0
  for ((j=2; j<i; j++))
    do
  
       if [ `expr $i % $j` -eq 0 ]
            then
              flag=1
               break
        fi       
    done
      if [ $flag -eq 0 ]
      then
         echo -n "$i "             
      fi
done

echo 