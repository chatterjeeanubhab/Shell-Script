echo -n "enter size::"
read n
echo "enter the elements"
for ((i=0;i<n;i++))
do
read arr[$i]
done

echo "Enter the element to be searched for"
read x

flag=0
for ((i=0;i<n;i++))
do

if [ ${arr[i]} -eq $x ]
then
    flag=1
    pos=$i
    break 
fi

done

if [ $flag -eq 1 ]
then
 echo "element found at position `expr $i + 1`"
else
  echo "Not found!!"

fi

