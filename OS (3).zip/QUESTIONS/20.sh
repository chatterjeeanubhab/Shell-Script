# Enter the no. of rows::
# 5
#         *
#       * * *
#     * * * * *
#       * * *
#         *
echo -n "Enter the no. of rows::"
read row
#upper part..........

for ((i=1; i <= $row/2 + 1; i++))
do 

#spaces loop

for ((space = 1 ; space <= $row-$i ; space++))
do
   echo -n "  "
done

#column loop

for ((j=1; j <= 2*$i-1 ; j++))
do

echo -n "* "

done

echo 

done

#lower part..........

for ((i=$row/2; i >= 1 ; i--))
do 

#spaces loop

for ((space = 1 ; space <= $row-$i ; space++))
do
   echo -n "  "
done

#column loop

for ((j=1; j <= 2*$i-1 ; j++))
do

echo -n "* "

done

echo 

done