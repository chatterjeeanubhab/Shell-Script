clear
echo "BASIC   DA    HRA    PF   GROSS" > out.txt
echo "enter basic pay::"
read basic
da=`echo "0.45 * $basic"|bc`
hra=`echo "0.15 * $basic"|bc`
pf=`echo "0.10 * $basic"|bc`
gross=`echo "$basic + $da + $hra - $pf"|bc`

echo "$basic   $da   $hra   $pf   $gross" >>out.txt