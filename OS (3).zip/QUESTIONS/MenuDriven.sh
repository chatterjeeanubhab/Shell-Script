sum(){

a=$1
b=$2
res=`expr $a + $b`
echo $res

}

sub(){

a=$1
b=$2
res=`expr $a - $b`
echo $res

}


while [ 1 ]
echo "enter 1 for addition enter 2 for subtraction"
read ch
echo "enter two numbers::"
read t1
read t2

do

if [ $ch -eq 1 ]
then
a=`sum $t1 $t2`
echo "$a"

elif [ $ch -eq 2 ]
then
a=`sub $t1 $t2`
echo "$a"
else
exit

fi

done