#pascal's triangle

echo -n "Enter the rows:: "
read n
temp=1
for ((i=0;i<n;i++))
do

#spaces

for ((spaces=1; spaces <= (n-i); spaces++ ))
do
echo -n "  "
done


#inner loop

for ((j=0;j<=i;j++))
do
if [ $j -eq 0 -o $i -eq 0 ]
then

   temp=1
else
  
   temp=`echo "$temp*($i-$j+1)/$j"|bc`
fi

echo -n "$temp   "

done

echo 


done